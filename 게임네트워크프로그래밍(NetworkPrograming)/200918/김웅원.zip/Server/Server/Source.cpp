#pragma comment(lib, "ws2_32.lib")
#include <WinSock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#define SERVERPORT 9000
#define BUFSIZE 512

#pragma region Error_Message_DEFINE
void Err_Quit(const char* msg)
{
	LPVOID lpmsgbuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpmsgbuf,
		0,
		NULL);
	MessageBox(NULL, (LPCSTR)lpmsgbuf, msg, MB_OK);
	LocalFree(lpmsgbuf);
	exit(-1);
}

void Err_Display(const char* msg)
{
	LPVOID lpmsgbuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		WSAGetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpmsgbuf,
		0,
		NULL);
	printf("[%s] %s\n", msg, (LPTSTR)lpmsgbuf);
	LocalFree(lpmsgbuf);
}
#pragma endregion

int recvn(SOCKET sock, char* buf, int len, int flags)
{
	char* ptr = buf;
	int left = len;
	int recived;

	while (left > 0)
	{
		recived = recv(sock, ptr, left, flags);
		if (recived == SOCKET_ERROR)
			return SOCKET_ERROR;
		else if (recived == 0)
			break;

		left -= recived;
		ptr += recived;
	}
	return (len - left);
}

#define INTRO "------���������� ����------\n"
#define	MSG_WIN "�¸��Ͽ����ϴ�.\n"
#define	MSG_LOSE "�й��Ͽ����ϴ�.\n"
#define	MSG_DRAW "�����ϴ�.\n"

enum
{
	WIN = 1,
	LOSE,
	DRAW
};

enum
{
	SCISSORS = 0,
	ROCK,
	PAPER
};

struct RSP
{
	int Val;
};

struct _Result
{
	int result;
	char msg[BUFSIZE];
};

int main()
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return 1;

	SOCKET listen_sock = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_sock == INVALID_SOCKET)
		Err_Quit("socket()");

	// binding..
	SOCKADDR_IN serveraddr;
	ZeroMemory(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(SERVERPORT);
	int retval = bind(listen_sock, (SOCKADDR*)&serveraddr, sizeof(serveraddr));
	if (listen_sock == SOCKET_ERROR)
		Err_Quit("bind()");

	retval = listen(listen_sock, SOMAXCONN);
	if (listen_sock == SOCKET_ERROR)
		Err_Quit("listen()");

	SOCKET client01_sock, client02_sock;
	SOCKADDR_IN client01_addr, client02_addr;
	int addrlen;
	char buf[BUFSIZE + 1];

	srand(time(NULL));

	while (1)
	{
		addrlen = sizeof(client01_addr);
		client01_sock = accept(listen_sock, (SOCKADDR*)&client01_addr, &addrlen);
		if (client01_sock == INVALID_SOCKET)
		{
			Err_Display("accept()");
			break;
		}

		printf("ù��° Ŭ���̾�Ʈ ����: IP = %s port = %d \n",
			inet_ntoa(client01_addr.sin_addr), ntohs(client01_addr.sin_port));

		addrlen = sizeof(client02_addr);
		client02_sock = accept(listen_sock, (SOCKADDR*)&client02_addr, &addrlen);
		if (client02_sock == INVALID_SOCKET)
		{
			Err_Display("accept()");
			break;
		}

		printf("�ι�° Ŭ���̾�Ʈ ����: IP = %s port = %d \n\n",
			inet_ntoa(client02_addr.sin_addr), ntohs(client02_addr.sin_port));


		retval = send(client01_sock, INTRO, strlen(INTRO), 0);
		if (retval == SOCKET_ERROR)
		{
			Err_Display("send()");
			continue;
		}
		retval = send(client02_sock, INTRO, strlen(INTRO), 0);
		if (retval == SOCKET_ERROR)
		{
			Err_Display("send()");
			continue;
		}

		RSP _User01_RSP, _User02_RSP;
		ZeroMemory(&_User01_RSP, sizeof(_User01_RSP));
		ZeroMemory(&_User02_RSP, sizeof(_User02_RSP));

		while (1)
		{
			retval = recvn(client01_sock, (char*)&_User01_RSP, sizeof(_User01_RSP), 0);
			if (retval == SOCKET_ERROR)
			{
				Err_Display("recvn()");
				break;
			}
			else if (retval == 0)
			{
				break;
			}
			retval = recvn(client02_sock, (char*)&_User02_RSP, sizeof(_User02_RSP), 0);
			if (retval == SOCKET_ERROR)
			{
				Err_Display("recvn()");
				break;
			}
			else if (retval == 0)
			{
				break;
			}

			printf("[ host_01(IP : %s) ] Player : %d\n",
				inet_ntoa(client01_addr.sin_addr), _User01_RSP.Val);
			printf("[ host_02(IP : %s) ] Player : %d\n",
				inet_ntoa(client02_addr.sin_addr), _User02_RSP.Val);

			_Result result01, result02;
			int ResultValue = abs(_User01_RSP.Val - (_User02_RSP.Val + 3));

			if (ResultValue == 3)
			{
				result01.result = DRAW;
				strcpy(result01.msg, MSG_DRAW);
				result02.result = DRAW;
				strcpy(result02.msg, MSG_DRAW);
				printf("[ Player01(%s) vs Player02(%s) ���������� ��� ] : %s\n\n",
					inet_ntoa(client01_addr.sin_addr), inet_ntoa(client02_addr.sin_addr), "Draw..");
			}
			else if (ResultValue == 4 || ResultValue == 1)
			{
				result01.result = LOSE;
				strcpy(result01.msg, MSG_LOSE);
				result02.result = WIN;
				strcpy(result02.msg, MSG_WIN);
				printf("[ Player01(%s) vs Player02(%s) ���������� ��� ] : %s\n\n",
					inet_ntoa(client01_addr.sin_addr), inet_ntoa(client02_addr.sin_addr), "Player02 Win");
			}
			else if (ResultValue == 5 || ResultValue == 2)
			{
				result01.result = WIN;
				strcpy(result01.msg, MSG_WIN);
				result02.result = LOSE;
				strcpy(result02.msg, MSG_LOSE);
				printf("[ Player01(%s) vs Player02(%s) ���������� ��� ] : %s\n\n",
					inet_ntoa(client01_addr.sin_addr), inet_ntoa(client02_addr.sin_addr), "Player01 Win");
			}

			

			retval = send(client01_sock, (char*)&result01, sizeof(result01), 0);
			if (retval == SOCKET_ERROR)
			{
				Err_Display("send()");
				break;
			}
			retval = send(client02_sock, (char*)&result02, sizeof(result02), 0);
			if (retval == SOCKET_ERROR)
			{
				Err_Display("send()");
				break;
			}

		}

		closesocket(client01_sock);
		closesocket(client02_sock);
		printf("1�� Ŭ���̾�Ʈ ����: IP = %s port = %d \n",
			inet_ntoa(client01_addr.sin_addr), ntohs(client01_addr.sin_port));
		printf("2�� Ŭ���̾�Ʈ ����: IP = %s port = %d \n\n",
			inet_ntoa(client02_addr.sin_addr), ntohs(client02_addr.sin_port));

	}

	closesocket(listen_sock);

	WSACleanup();
	return 0;
}